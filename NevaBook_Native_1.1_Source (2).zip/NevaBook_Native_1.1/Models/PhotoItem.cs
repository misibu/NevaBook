using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Media.Imaging;

namespace NevaBook.Models;

public sealed class PhotoItem : INotifyPropertyChanged
{
    public Guid Id { get; } = Guid.NewGuid();
    public required string SourcePath { get; init; }
    public required string WorkingPath { get; init; }
    public required int Width { get; init; }
    public required int Height { get; init; }

    public string Name => Path.GetFileName(SourcePath);
    public double Aspect => Width / (double)Math.Max(1, Height);
    public string Orientation => Aspect >= 1.0 ? "Горизонтальная" : "Вертикальная";

    private bool _isUsed;
    public bool IsUsed
    {
        get => _isUsed;
        set
        {
            if (_isUsed == value) return;
            _isUsed = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(Status));
        }
    }

    public string Status => IsUsed ? "В макете" : "Свободно";

    private BitmapSource? _thumbnail;
    public BitmapSource? Thumbnail
    {
        get => _thumbnail;
        set
        {
            if (ReferenceEquals(_thumbnail, value)) return;
            _thumbnail = value;
            OnPropertyChanged();
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
