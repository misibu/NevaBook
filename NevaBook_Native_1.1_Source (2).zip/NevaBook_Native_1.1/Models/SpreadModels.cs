namespace NevaBook.Models;

public readonly record struct RectMm(double X, double Y, double Width, double Height)
{
    public double Aspect => Width / Math.Max(0.000001, Height);
    public double Area => Width * Height;
}

public sealed class PlacedPhoto
{
    public required PhotoItem Photo { get; set; }
    public required RectMm Rect { get; set; }
    public double FocusX { get; set; } = 0.5;
    public double FocusY { get; set; } = 0.5;

    public PlacedPhoto Clone() => new()
    {
        Photo = Photo,
        Rect = Rect,
        FocusX = FocusX,
        FocusY = FocusY
    };
}

public sealed class Spread
{
    public List<PlacedPhoto> Items { get; } = [];
    public List<List<RectMm>> Variants { get; } = [];
    public int LayoutIndex { get; set; }
    public int Seed { get; init; }
    public int Version { get; private set; }

    public void Touch() => Version++;

    public Spread Clone()
    {
        var s = new Spread { Seed = Seed, LayoutIndex = LayoutIndex };
        s.Items.AddRange(Items.Select(x => x.Clone()));
        foreach (var variant in Variants)
            s.Variants.Add([.. variant]);
        return s;
    }
}
