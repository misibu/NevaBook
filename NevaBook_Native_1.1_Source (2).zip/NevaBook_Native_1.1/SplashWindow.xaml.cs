using System.Windows;

namespace NevaBook;

public partial class SplashWindow : Window
{
    public SplashWindow()
    {
        InitializeComponent();
    }
}
