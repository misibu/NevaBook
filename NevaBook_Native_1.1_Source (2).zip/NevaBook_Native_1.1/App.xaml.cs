using System.Windows;

namespace NevaBook;

public partial class App : Application
{
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var splash = new SplashWindow();
        splash.Show();

        // The 4-second branded splash is intentional and requested.
        await Task.Delay(4000);

        var main = new MainWindow();
        MainWindow = main;
        ShutdownMode = ShutdownMode.OnMainWindowClose;
        main.Show();

        splash.Close();
    }
}
