using Microsoft.Win32;
using NevaBook.Controls;
using NevaBook.Models;
using NevaBook.Services;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Input;

namespace NevaBook;

public partial class MainWindow : Window
{
    public ObservableCollection<PhotoItem> Photos { get; } = [];

    private readonly BitmapCache _bitmapCache = new();
    private readonly ImageImportService _importer;
    private readonly LayoutEngine _layoutEngine = new();
    private readonly PdfPrintService _pdfService = new();

    private readonly List<Spread> _spreads = [];
    private int _currentSpread;
    private Point _photoDragStart;

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;
        _importer = new ImageImportService(_bitmapCache);

        SpreadView.PageWidthMm = 406;
        SpreadView.PageHeightMm = 206;
        SpreadView.ShowFold = true;
    }

    private async void AddPhotos_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Title = "Выберите фотографии",
            Multiselect = true,
            Filter = "Фотографии|*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.bmp;*.webp;*.heic;*.heif;*.dng;*.cr2;*.cr3;*.nef;*.nrw;*.arw;*.orf;*.rw2;*.raf;*.pef;*.srw;*.raw|Все файлы|*.*"
        };

        if (dlg.ShowDialog() == true)
            await AddPathsAsync(dlg.FileNames);
    }

    private async void AddFolder_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFolderDialog
        {
            Title = "Выберите папку с фотографиями",
            Multiselect = false
        };

        if (dlg.ShowDialog() != true)
            return;

        var paths = Directory.EnumerateFiles(dlg.FolderName)
            .Where(_importer.IsSupported)
            .OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();

        await AddPathsAsync(paths);
    }

    private async Task AddPathsAsync(IEnumerable<string> paths)
    {
        var existing = Photos.Select(x => Path.GetFullPath(x.SourcePath))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var list = paths.Where(x => !existing.Contains(Path.GetFullPath(x))).ToArray();
        if (list.Length == 0) return;

        Progress.Minimum = 0;
        Progress.Maximum = list.Length;
        Progress.Value = 0;

        int done = 0;
        foreach (var path in list)
        {
            try
            {
                StatusText.Text = $"Импорт: {Path.GetFileName(path)}";
                var photo = await _importer.ImportAsync(path);
                Photos.Add(photo);
                _ = _importer.LoadThumbnailAsync(photo);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Не удалось импортировать:\n{path}\n\n{ex.Message}",
                    "Импорт", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            Progress.Value = ++done;
        }

        Progress.Value = 0;
        PhotoCountText.Text = Photos.Count.ToString();
        StatusText.Text = $"Загружено фотографий: {Photos.Count}";
    }

    private void RemovePhotos_Click(object sender, RoutedEventArgs e)
    {
        var selected = PhotoList.SelectedItems.Cast<PhotoItem>().ToArray();
        if (selected.Length == 0) return;

        bool used = selected.Any(x => x.IsUsed);
        if (used)
        {
            var result = MessageBox.Show(
                "Некоторые выбранные фотографии уже стоят в макетах.\n" +
                "После удаления текущая автораскладка будет сброшена.\n\nПродолжить?",
                "Удалить фотографии",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes) return;
            ClearLayout();
        }

        foreach (var p in selected)
            Photos.Remove(p);

        PhotoCountText.Text = Photos.Count.ToString();
        StatusText.Text = $"Фотографий: {Photos.Count}";
    }

    private void AutoLayout_Click(object sender, RoutedEventArgs e)
    {
        if (!TryReadSettings(out double w, out double h, out double gap, out _, out int spreadCount))
            return;

        if (Photos.Count < spreadCount)
        {
            MessageBox.Show("Фотографий меньше, чем разворотов.", "Авторазмещение");
            return;
        }

        ClearLayout();

        int baseCount = Photos.Count / spreadCount;
        int remainder = Photos.Count % spreadCount;
        int index = 0;

        Progress.Minimum = 0;
        Progress.Maximum = spreadCount;

        for (int i = 0; i < spreadCount; i++)
        {
            int count = baseCount + (i < remainder ? 1 : 0);
            var group = Photos.Skip(index).Take(count).ToArray();
            index += count;

            StatusText.Text = $"Строю разворот {i + 1}/{spreadCount}…";
            _spreads.Add(_layoutEngine.GenerateSpread(group, w, h, gap));
            Progress.Value = i + 1;
        }

        foreach (var p in Photos) p.IsUsed = false;
        foreach (var placed in _spreads.SelectMany(x => x.Items))
            placed.Photo.IsUsed = true;

        _currentSpread = 0;
        SpreadView.PageWidthMm = w;
        SpreadView.PageHeightMm = h;
        ShowCurrentSpread();

        Progress.Value = 0;
        StatusText.Text = $"Готово: {Photos.Count} фото / {spreadCount} разворотов.";
    }

    private void NextVariant_Click(object sender, RoutedEventArgs e)
    {
        if (_spreads.Count == 0) return;
        var spread = _spreads[_currentSpread];
        if (spread.Variants.Count == 0) return;

        int next = (spread.LayoutIndex + 1) % spread.Variants.Count;
        _layoutEngine.ApplyVariant(spread, next);
        ShowCurrentSpread();
    }

    private void PreviousSpread_Click(object sender, RoutedEventArgs e)
    {
        if (_spreads.Count == 0 || _currentSpread <= 0) return;
        _currentSpread--;
        ShowCurrentSpread();
    }

    private void NextSpread_Click(object sender, RoutedEventArgs e)
    {
        if (_spreads.Count == 0 || _currentSpread >= _spreads.Count - 1) return;
        _currentSpread++;
        ShowCurrentSpread();
    }

    private void ShowCurrentSpread()
    {
        if (_spreads.Count == 0)
        {
            SpreadView.Spread = null;
            SpreadText.Text = "Разворот —";
            VariantText.Text = "";
            return;
        }

        var spread = _spreads[_currentSpread];
        SpreadView.Spread = spread;
        SpreadText.Text = $"Разворот {_currentSpread + 1} / {_spreads.Count}";
        VariantText.Text = spread.Variants.Count > 0
            ? $"Макет {spread.LayoutIndex + 1} / {spread.Variants.Count}"
            : "";
    }

    private void SpreadView_LayoutChanged(object? sender, EventArgs e)
    {
        RefreshUsage();
        StatusText.Text = "Макет изменён.";
    }

    private void SpreadView_ExternalPhotoDropped(object? sender, PhotoDropEventArgs e)
    {
        if (_spreads.Count == 0) return;
        var targetSpread = _spreads[_currentSpread];
        if (e.TargetIndex < 0 || e.TargetIndex >= targetSpread.Items.Count) return;

        var targetItem = targetSpread.Items[e.TargetIndex];
        if (targetItem.Photo.Id == e.Photo.Id) return;

        PlacedPhoto? sourcePlaced = null;
        Spread? sourceSpread = null;

        foreach (var spread in _spreads)
        {
            sourcePlaced = spread.Items.FirstOrDefault(x => x.Photo.Id == e.Photo.Id);
            if (sourcePlaced is not null)
            {
                sourceSpread = spread;
                break;
            }
        }

        if (sourcePlaced is not null && sourceSpread is not null)
        {
            var displaced = targetItem.Photo;
            targetItem.Photo = e.Photo;
            targetItem.FocusX = targetItem.FocusY = 0.5;

            sourcePlaced.Photo = displaced;
            sourcePlaced.FocusX = sourcePlaced.FocusY = 0.5;
            sourceSpread.Touch();
        }
        else
        {
            var displaced = targetItem.Photo;
            targetItem.Photo = e.Photo;
            targetItem.FocusX = targetItem.FocusY = 0.5;
            displaced.IsUsed = false;
        }

        targetSpread.Touch();
        RefreshUsage();
        ShowCurrentSpread();
        StatusText.Text = "Фотографии заменены перетаскиванием.";
    }

    private async void ExportJpeg_Click(object sender, RoutedEventArgs e)
    {
        if (_spreads.Count == 0)
        {
            MessageBox.Show("Сначала создайте раскладку.");
            return;
        }

        if (!TryReadSettings(out double w, out double h, out _, out int dpi, out _))
            return;

        var dlg = new OpenFolderDialog
        {
            Title = "Куда сохранить готовые развороты?",
            Multiselect = false
        };

        if (dlg.ShowDialog() != true)
            return;

        Progress.Minimum = 0;
        Progress.Maximum = _spreads.Count;

        try
        {
            for (int i = 0; i < _spreads.Count; i++)
            {
                int index = i;
                string path = Path.Combine(dlg.FolderName, $"spread_{index + 1:00}.jpg");
                StatusText.Text = $"Экспорт {index + 1}/{_spreads.Count}…";

                await Task.Run(() =>
                    SpreadRasterizer.SaveJpeg(_spreads[index].Clone(), path, w, h, dpi));

                Progress.Value = index + 1;
            }

            StatusText.Text = "Экспорт завершён.";
        }
        finally
        {
            Progress.Value = 0;
        }
    }

    private async void PrintA3_Click(object sender, RoutedEventArgs e)
    {
        if (_spreads.Count == 0)
        {
            MessageBox.Show("Сначала создайте раскладку.");
            return;
        }

        if (!TryReadSettings(out double w, out double h, out _, out int dpi, out _))
            return;

        var dlg = new SaveFileDialog
        {
            Title = "Сохранить PDF для печати A3",
            Filter = "PDF|*.pdf",
            DefaultExt = ".pdf",
            FileName = "Neva-Book_A3_print.pdf"
        };
        if (dlg.ShowDialog() != true) return;

        Progress.Minimum = 0;
        Progress.Maximum = _spreads.Count;

        try
        {
            var progress = new Progress<(int Done, int Total)>(p =>
            {
                Progress.Value = p.Done;
                StatusText.Text = $"Формирование A3 PDF: {p.Done}/{p.Total}";
            });

            await _pdfService.ExportAsync(_spreads, dlg.FileName, w, h, dpi, progress);
            StatusText.Text = "A3 PDF готов.";

            try
            {
                Process.Start(new ProcessStartInfo(dlg.FileName) { UseShellExecute = true });
            }
            catch { }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "A3 PDF", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            Progress.Value = 0;
        }
    }

    private void PhotoList_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _photoDragStart = e.GetPosition(PhotoList);
    }

    private void PhotoList_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed) return;

        Point current = e.GetPosition(PhotoList);
        if (Math.Abs(current.X - _photoDragStart.X) < SystemParameters.MinimumHorizontalDragDistance &&
            Math.Abs(current.Y - _photoDragStart.Y) < SystemParameters.MinimumVerticalDragDistance)
            return;

        if (PhotoList.SelectedItem is PhotoItem photo)
            DragDrop.DoDragDrop(PhotoList, photo, DragDropEffects.Move);
    }

    private void FoldCheck_Changed(object sender, RoutedEventArgs e)
    {
        if (SpreadView is null) return;
        SpreadView.ShowFold = FoldCheck.IsChecked == true;
        SpreadView.InvalidateVisual();
    }

    private void RefreshUsage()
    {
        var used = _spreads.SelectMany(x => x.Items).Select(x => x.Photo.Id).ToHashSet();
        foreach (var photo in Photos)
            photo.IsUsed = used.Contains(photo.Id);
    }

    private void ClearLayout()
    {
        _spreads.Clear();
        foreach (var p in Photos) p.IsUsed = false;
        _currentSpread = 0;
        ShowCurrentSpread();
    }

    private bool TryReadSettings(
        out double w, out double h, out double gap, out int dpi, out int spreadCount)
    {
        bool ok =
            TryDouble(WidthBox.Text, out w) &&
            TryDouble(HeightBox.Text, out h) &&
            TryDouble(GapBox.Text, out gap) &&
            int.TryParse(DpiBox.Text, out dpi) &&
            int.TryParse(SpreadCountBox.Text, out spreadCount) &&
            w > 0 && h > 0 && gap >= 0 && dpi >= 72 && spreadCount > 0;

        if (!ok)
        {
            MessageBox.Show("Проверьте размер, зазор, DPI и количество разворотов.");
            w = 406; h = 206; gap = 2; dpi = 300; spreadCount = 10;
        }

        return ok;
    }

    private static bool TryDouble(string text, out double value) =>
        double.TryParse(text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value);
}
