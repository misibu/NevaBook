#define MyAppName "Neva-Book1.1"
#define MyAppVersion "1.1"
#define MyAppPublisher "Neva-Book"
#define MyAppExeName "Neva-Book1.1.exe"

[Setup]
AppId={{4C96FEC5-B9D6-4AB8-8CB6-C16108C8E111}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Neva-Book1.1
DefaultGroupName=Neva-Book1.1
DisableProgramGroupPage=yes
OutputDir=..\artifacts
OutputBaseFilename=Neva-Book1.1_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=..\Assets\app.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
WizardImageFile=wizard_large.bmp
WizardSmallImageFile=wizard_small.bmp
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Дополнительные задачи:"; Flags: unchecked

[Files]
Source: "..\publish\installed\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Neva-Book1.1"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Neva-Book1.1"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Запустить Neva-Book1.1"; Flags: nowait postinstall skipifsilent
