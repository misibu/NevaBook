using System.Reflection;
using NevaBook.Models;
using PdfSharp.Drawing;
using PdfSharp.Pdf;

namespace NevaBook.Services;

public sealed class PdfPrintService
{
    private const double A3W = 420.0;
    private const double A3H = 297.0;

    private const double TemplatePxW = 2048.0;
    private const double TemplatePxH = 1448.0;
    private const double GuideLeftPx = 16.0;
    private const double GuideRightPx = 2035.0;
    private const double GuideTopPx = 209.0;
    private const double GuideBottomPx = 1234.0;

    public async Task ExportAsync(
        IReadOnlyList<Spread> spreads,
        string outputPath,
        double spreadWidthMm,
        double spreadHeightMm,
        int dpi,
        IProgress<(int Done, int Total)>? progress = null,
        CancellationToken token = default)
    {
        var snapshot = spreads.Select(x => x.Clone()).ToArray();
        byte[] underlay = LoadUnderlay();

        await Task.Run(() =>
        {
            var document = new PdfDocument();
            document.Info.Title = "Neva-Book1.1 — A3 печать";

            var templateGeometry = TemplateGeometryMm();
            double spreadX = (A3W - spreadWidthMm) / 2.0;
            double spreadY = (A3H - spreadHeightMm) / 2.0;

            for (int i = 0; i < snapshot.Length; i++)
            {
                token.ThrowIfCancellationRequested();

                var page = document.AddPage();
                page.Width = XUnit.FromMillimeter(A3W);
                page.Height = XUnit.FromMillimeter(A3H);

                using var gfx = XGraphics.FromPdfPage(page);
                using var templateStream = new MemoryStream(underlay, writable: false);
                using var templateImage = XImage.FromStream(templateStream);

                gfx.DrawImage(
                    templateImage,
                    XUnit.FromMillimeter(templateGeometry.X).Point,
                    XUnit.FromMillimeter(templateGeometry.Y).Point,
                    XUnit.FromMillimeter(templateGeometry.W).Point,
                    XUnit.FromMillimeter(templateGeometry.H).Point);

                byte[] spreadBytes = SpreadRasterizer.RenderJpeg(
                    snapshot[i], spreadWidthMm, spreadHeightMm, dpi);

                using var spreadStream = new MemoryStream(spreadBytes, writable: false);
                using var spreadImage = XImage.FromStream(spreadStream);
                gfx.DrawImage(
                    spreadImage,
                    XUnit.FromMillimeter(spreadX).Point,
                    XUnit.FromMillimeter(spreadY).Point,
                    XUnit.FromMillimeter(spreadWidthMm).Point,
                    XUnit.FromMillimeter(spreadHeightMm).Point);

                progress?.Report((i + 1, snapshot.Length));
            }

            document.Save(outputPath);
        }, token);
    }

    private static (double X, double Y, double W, double H) TemplateGeometryMm()
    {
        // Same calibration as the last stable Python build:
        // the dark guide rectangle maps exactly to centered 406 x 206 mm.
        double guideW = GuideRightPx - GuideLeftPx;
        double guideH = GuideBottomPx - GuideTopPx;
        double sx = 406.0 / guideW;
        double sy = 206.0 / guideH;

        double templateW = TemplatePxW * sx;
        double templateH = TemplatePxH * sy;

        double spreadLeft = (A3W - 406.0) / 2.0;
        double spreadTop = (A3H - 206.0) / 2.0;

        double templateX = spreadLeft - GuideLeftPx * sx;
        double templateY = spreadTop - GuideTopPx * sy;

        return (templateX, templateY, templateW, templateH);
    }

    private static byte[] LoadUnderlay()
    {
        var asm = Assembly.GetExecutingAssembly();
        using Stream stream = asm.GetManifestResourceStream("Assets.a3_underlay.jpg")
            ?? throw new InvalidOperationException("Встроенная A3-подложка не найдена.");
        using var ms = new MemoryStream();
        stream.CopyTo(ms);
        return ms.ToArray();
    }
}
