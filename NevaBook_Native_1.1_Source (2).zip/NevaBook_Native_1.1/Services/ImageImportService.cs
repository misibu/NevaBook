using System.Security.Cryptography;
using System.Text;
using ImageMagick;
using NevaBook.Models;

namespace NevaBook.Services;

public sealed class ImageImportService
{
    private static readonly HashSet<string> Supported = new(StringComparer.OrdinalIgnoreCase)
    {
        ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp",
        ".heic", ".heif",
        ".raw", ".dng", ".cr2", ".cr3", ".nef", ".nrw", ".arw", ".srf", ".sr2",
        ".orf", ".rw2", ".raf", ".pef", ".ptx", ".srw", ".rwl", ".3fr", ".iiq"
    };

    private readonly string _cacheDir;
    private readonly BitmapCache _bitmapCache;

    public ImageImportService(BitmapCache bitmapCache)
    {
        _bitmapCache = bitmapCache;
        _cacheDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Neva-Book1.1", "converted_jpg");
        Directory.CreateDirectory(_cacheDir);
    }

    public bool IsSupported(string path) => Supported.Contains(Path.GetExtension(path));

    public async Task<PhotoItem> ImportAsync(string sourcePath, CancellationToken token = default)
    {
        return await Task.Run(() =>
        {
            token.ThrowIfCancellationRequested();

            string full = Path.GetFullPath(sourcePath);
            var info = new FileInfo(full);
            if (!info.Exists) throw new FileNotFoundException("Файл не найден.", full);
            if (!IsSupported(full))
                throw new InvalidOperationException($"Неподдерживаемый формат: {info.Extension}");

            string working = GetCachePath(info);

            if (!File.Exists(working) || new FileInfo(working).Length == 0)
            {
                string temp = working + ".tmp.jpg";
                using var image = new MagickImage(full);
                image.AutoOrient();
                image.ColorSpace = ColorSpace.sRGB;

                if (image.HasAlpha)
                {
                    image.BackgroundColor = MagickColors.White;
                    image.Alpha(AlphaOption.Remove);
                }

                image.Format = MagickFormat.Jpeg;
                image.Quality = 98;
                image.Settings.SetDefine(MagickFormat.Jpeg, "sampling-factor", "4:4:4");
                image.Write(temp);

                if (File.Exists(working)) File.Delete(working);
                File.Move(temp, working);
            }

            using var probe = new MagickImage(working);
            return new PhotoItem
            {
                SourcePath = full,
                WorkingPath = working,
                Width = checked((int)probe.Width),
                Height = checked((int)probe.Height)
            };
        }, token);
    }

    public async Task LoadThumbnailAsync(PhotoItem photo)
    {
        photo.Thumbnail = await _bitmapCache.GetAsync(photo.WorkingPath, 260);
    }

    private string GetCachePath(FileInfo info)
    {
        string key = $"{info.FullName}|{info.Length}|{info.LastWriteTimeUtc.Ticks}";
        byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes(key));
        string digest = Convert.ToHexString(hash)[..20];

        string stem = string.Concat(Path.GetFileNameWithoutExtension(info.Name)
            .Select(c => char.IsLetterOrDigit(c) || c is '-' or '_' ? c : '_'));

        if (stem.Length > 60) stem = stem[..60];
        return Path.Combine(_cacheDir, $"{stem}_{digest}.jpg");
    }
}
