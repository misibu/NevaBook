using System.Collections.Concurrent;
using System.Windows.Media.Imaging;

namespace NevaBook.Services;

public sealed class BitmapCache
{
    private readonly ConcurrentDictionary<string, BitmapSource> _cache =
        new(StringComparer.OrdinalIgnoreCase);

    public event EventHandler? ImageReady;

    public bool TryGet(string path, out BitmapSource bitmap) =>
        _cache.TryGetValue(path, out bitmap!);

    public async Task<BitmapSource?> GetAsync(string path, int decodePixelWidth = 1800)
    {
        if (_cache.TryGetValue(path, out var cached))
            return cached;

        try
        {
            var bitmap = await Task.Run(() => LoadFrozen(path, decodePixelWidth));
            _cache[path] = bitmap;
            ImageReady?.Invoke(this, EventArgs.Empty);
            return bitmap;
        }
        catch
        {
            return null;
        }
    }

    public Task PreloadAsync(IEnumerable<string> paths) =>
        Task.WhenAll(paths.Distinct(StringComparer.OrdinalIgnoreCase)
            .Select(path => GetAsync(path)));

    public void Remove(string path) => _cache.TryRemove(path, out _);
    public void Clear() => _cache.Clear();

    public static BitmapSource LoadFrozen(string path, int decodePixelWidth)
    {
        using var fs = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        var bmp = new BitmapImage();
        bmp.BeginInit();
        bmp.CacheOption = BitmapCacheOption.OnLoad;
        bmp.DecodePixelWidth = decodePixelWidth;
        bmp.StreamSource = fs;
        bmp.EndInit();
        bmp.Freeze();
        return bmp;
    }
}
