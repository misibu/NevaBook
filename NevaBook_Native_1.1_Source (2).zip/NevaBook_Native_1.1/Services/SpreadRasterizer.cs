using ImageMagick;
using NevaBook.Models;

namespace NevaBook.Services;

public static class SpreadRasterizer
{
    public static byte[] RenderJpeg(
        Spread spread,
        double pageWidthMm,
        double pageHeightMm,
        int dpi,
        int quality = 96)
    {
        int pixelW = Math.Max(1, (int)Math.Round(pageWidthMm / 25.4 * dpi));
        int pixelH = Math.Max(1, (int)Math.Round(pageHeightMm / 25.4 * dpi));

        using var canvas = new MagickImage(MagickColors.White, (uint)pixelW, (uint)pixelH);

        double sx = pixelW / pageWidthMm;
        double sy = pixelH / pageHeightMm;

        foreach (var placed in spread.Items)
        {
            int x0 = (int)Math.Round(placed.Rect.X * sx);
            int y0 = (int)Math.Round(placed.Rect.Y * sy);
            int x1 = (int)Math.Round((placed.Rect.X + placed.Rect.Width) * sx);
            int y1 = (int)Math.Round((placed.Rect.Y + placed.Rect.Height) * sy);
            int tw = Math.Max(1, x1 - x0);
            int th = Math.Max(1, y1 - y0);

            try
            {
                using var image = new MagickImage(placed.Photo.SourcePath);
                image.AutoOrient();

                if (image.HasAlpha)
                {
                    image.BackgroundColor = MagickColors.White;
                    image.Alpha(AlphaOption.Remove);
                }

                double scale = Math.Max(tw / (double)image.Width, th / (double)image.Height);
                uint newW = (uint)Math.Max(tw, (int)Math.Ceiling(image.Width * scale));
                uint newH = (uint)Math.Max(th, (int)Math.Ceiling(image.Height * scale));
                image.Resize(newW, newH);

                int overflowX = Math.Max(0, checked((int)image.Width) - tw);
                int overflowY = Math.Max(0, checked((int)image.Height) - th);
                int left = (int)Math.Round(overflowX * Math.Clamp(placed.FocusX, 0, 1));
                int top = (int)Math.Round(overflowY * Math.Clamp(placed.FocusY, 0, 1));

                image.Crop(new MagickGeometry(left, top, (uint)tw, (uint)th));
                image.RePage();
                canvas.Composite(image, x0, y0, CompositeOperator.Over);
            }
            catch
            {
                using var failed = new MagickImage(new MagickColor("#DCDCDC"), (uint)tw, (uint)th);
                canvas.Composite(failed, x0, y0, CompositeOperator.Over);
            }
        }

        canvas.Format = MagickFormat.Jpeg;
        canvas.Quality = quality;
        canvas.Settings.SetDefine(MagickFormat.Jpeg, "sampling-factor", "4:4:4");
        return canvas.ToByteArray();
    }

    public static void SaveJpeg(
        Spread spread,
        string path,
        double pageWidthMm,
        double pageHeightMm,
        int dpi)
    {
        File.WriteAllBytes(path, RenderJpeg(spread, pageWidthMm, pageHeightMm, dpi));
    }
}
