using NevaBook.Models;

namespace NevaBook.Services;

/// <summary>
/// Native C# port of the layout logic that behaved correctly in the Python v0.3.1 branch.
/// It keeps the same ideas: clean recursive splits, hero images, crop-cost ranking,
/// 36 layout variants and focus preservation.
/// </summary>
public sealed class LayoutEngine
{
    public Spread GenerateSpread(
        IReadOnlyList<PhotoItem> photos,
        double pageWidthMm,
        double pageHeightMm,
        double gapMm,
        int? seed = null,
        int targetVariants = 36)
    {
        if (photos.Count == 0)
            return new Spread { Seed = seed ?? 0 };

        int actualSeed = seed ?? Random.Shared.Next(1, int.MaxValue);
        var variants = BuildLayoutVariants(
            photos, pageWidthMm, pageHeightMm, gapMm, actualSeed, targetVariants);

        var spread = new Spread { Seed = actualSeed };
        foreach (var v in variants)
            spread.Variants.Add(v);

        spread.Items.AddRange(ApplyVariantWithFocus(photos, variants[0], null));
        return spread;
    }

    public void ApplyVariant(Spread spread, int variantIndex)
    {
        if (spread.Variants.Count == 0) return;
        variantIndex = ((variantIndex % spread.Variants.Count) + spread.Variants.Count) % spread.Variants.Count;

        var photos = spread.Items.Select(x => x.Photo).ToArray();
        var old = spread.Items.Select(x => x.Clone()).ToArray();
        var placed = ApplyVariantWithFocus(photos, spread.Variants[variantIndex], old);

        spread.Items.Clear();
        spread.Items.AddRange(placed);
        spread.LayoutIndex = variantIndex;
        spread.Touch();
    }

    private List<List<RectMm>> BuildLayoutVariants(
        IReadOnlyList<PhotoItem> photos,
        double pageW,
        double pageH,
        double gap,
        int seed,
        int targetCount)
    {
        var master = new Random(seed);
        var seen = new HashSet<string>();
        var scored = new List<(double Score, List<RectMm> Rects)>();
        int attempts = Math.Max(180, targetCount * 8);

        for (int i = 0; i < attempts; i++)
        {
            var rng = new Random(master.Next(1, int.MaxValue));
            var rects = CleanRecursiveRects(0, 0, pageW, pageH, photos.Count, gap, rng);
            var sig = RectSignature(rects);
            if (!seen.Add(sig)) continue;

            double score = AssignmentScore(photos, rects) + LayoutPenalty(rects);

            int bad = 0;
            foreach (var r in rects)
            {
                double a = r.Aspect;
                if (a > 3.3 || a < 0.30) bad++;
            }
            score += bad * 0.18;
            scored.Add((score, rects));
        }

        var variants = scored
            .OrderBy(x => x.Score)
            .Take(targetCount)
            .Select(x => x.Rects)
            .ToList();

        if (variants.Count == 0)
            variants.Add([new RectMm(0, 0, pageW, pageH)]);

        return variants;
    }

    private static string RectSignature(IEnumerable<RectMm> rects) =>
        string.Join("|", rects.SelectMany(r => new[] { r.X, r.Y, r.Width, r.Height })
                              .Select(v => Math.Round(v, 2).ToString("0.00")));

    private static List<RectMm> CleanRecursiveRects(
        double x, double y, double w, double h, int n, double gap, Random rng)
    {
        if (n <= 1) return [new RectMm(x, y, w, h)];

        double shape = w / Math.Max(h, 1e-9);
        bool vertical = shape > 1.45
            ? rng.NextDouble() < 0.86
            : shape < 0.70
                ? rng.NextDouble() < 0.14
                : rng.NextDouble() < 0.5;

        int k;
        if (n >= 3 && rng.NextDouble() < 0.45)
            k = rng.NextDouble() < 0.5 ? 1 : n - 1;
        else
            k = WeightedBalancedSplit(n, rng);

        double ratio;
        if (k == 1 || n - k == 1)
        {
            double[] choices = [0.36, 0.40, 0.42, 0.50, 0.58, 0.60, 0.64];
            ratio = choices[rng.Next(choices.Length)];
        }
        else
        {
            double ideal = k / (double)n;
            double[] choices = [0.333, 0.40, 0.50, 0.60, 0.667];
            ratio = choices.OrderBy(r => Math.Abs(r - ideal)).Take(3).ElementAt(rng.Next(3));
        }

        if (vertical)
        {
            double usable = w - gap;
            double w1 = usable * ratio;
            double w2 = usable - w1;
            if (Math.Min(w1, w2) < 18)
            {
                w1 = usable * 0.5;
                w2 = usable - w1;
            }
            var a = CleanRecursiveRects(x, y, w1, h, k, gap, rng);
            var b = CleanRecursiveRects(x + w1 + gap, y, w2, h, n - k, gap, rng);
            a.AddRange(b);
            return a;
        }
        else
        {
            double usable = h - gap;
            double h1 = usable * ratio;
            double h2 = usable - h1;
            if (Math.Min(h1, h2) < 18)
            {
                h1 = usable * 0.5;
                h2 = usable - h1;
            }
            var a = CleanRecursiveRects(x, y, w, h1, k, gap, rng);
            var b = CleanRecursiveRects(x, y + h1 + gap, w, h2, n - k, gap, rng);
            a.AddRange(b);
            return a;
        }
    }

    private static int WeightedBalancedSplit(int n, Random rng)
    {
        double center = n / 2.0;
        var candidates = Enumerable.Range(1, n - 1).ToArray();
        var weights = candidates.Select(k => 1.0 / (1.0 + Math.Abs(k - center))).ToArray();
        double total = weights.Sum();
        double pick = rng.NextDouble() * total;

        double cumulative = 0;
        for (int i = 0; i < candidates.Length; i++)
        {
            cumulative += weights[i];
            if (pick <= cumulative)
                return candidates[i];
        }
        return candidates[^1];
    }

    private static double CropCost(double photoAspect, double slotAspect)
    {
        double keep = Math.Min(photoAspect / slotAspect, slotAspect / photoAspect);
        return 1.0 - keep;
    }

    private static double LayoutPenalty(IReadOnlyList<RectMm> rects)
    {
        double penalty = 0;
        var areas = new List<double>();

        foreach (var r in rects)
        {
            areas.Add(r.Area);
            if (r.Width < 32) penalty += (32 - r.Width) * 0.025;
            if (r.Height < 30) penalty += (30 - r.Height) * 0.028;

            double a = r.Aspect;
            if (a > 4.2) penalty += (a - 4.2) * 0.18;
            if (a < 0.24) penalty += (0.24 - a) * 0.8;
        }

        if (areas.Count >= 4)
        {
            double avg = areas.Average();
            double sizeVariation = areas.Max() / Math.Max(avg, 1e-9);
            if (sizeVariation < 1.25) penalty += 0.08;
        }

        return penalty;
    }

    private static double AssignmentScore(IReadOnlyList<PhotoItem> photos, IReadOnlyList<RectMm> rects)
    {
        return BestPermutation(photos, rects).Score;
    }

    private static List<PlacedPhoto> ApplyVariantWithFocus(
        IReadOnlyList<PhotoItem> photos,
        IReadOnlyList<RectMm> rects,
        IReadOnlyList<PlacedPhoto>? oldItems)
    {
        var focus = oldItems?.ToDictionary(x => x.Photo.Id, x => (x.FocusX, x.FocusY))
                    ?? new Dictionary<Guid, (double, double)>();

        var result = BestPermutation(photos, rects);
        var placed = new List<PlacedPhoto>(photos.Count);

        for (int slot = 0; slot < rects.Count; slot++)
        {
            var photo = photos[result.Permutation[slot]];
            var p = new PlacedPhoto { Photo = photo, Rect = rects[slot] };
            if (focus.TryGetValue(photo.Id, out var f))
            {
                p.FocusX = f.Item1;
                p.FocusY = f.Item2;
            }
            placed.Add(p);
        }

        return placed;
    }

    private static (double Score, int[] Permutation) BestPermutation(
        IReadOnlyList<PhotoItem> photos,
        IReadOnlyList<RectMm> rects)
    {
        int n = photos.Count;
        var areas = rects.Select(r => r.Area).ToArray();
        double maxArea = areas.Length == 0 ? 1 : areas.Max();

        var costs = new double[n, n];
        for (int slot = 0; slot < n; slot++)
        {
            double areaWeight = 0.65 + 0.70 * (areas[slot] / maxArea);
            for (int p = 0; p < n; p++)
                costs[slot, p] = CropCost(photos[p].Aspect, rects[slot].Aspect) * areaWeight;
        }

        if (n <= 7)
        {
            double best = double.PositiveInfinity;
            int[] bestPerm = Enumerable.Range(0, n).ToArray();
            var current = new int[n];
            var used = new bool[n];

            void Walk(int depth, double score)
            {
                if (score >= best) return;
                if (depth == n)
                {
                    best = score;
                    Array.Copy(current, bestPerm, n);
                    return;
                }

                for (int p = 0; p < n; p++)
                {
                    if (used[p]) continue;
                    used[p] = true;
                    current[depth] = p;
                    Walk(depth + 1, score + costs[depth, p]);
                    used[p] = false;
                }
            }

            Walk(0, 0);
            return (best, bestPerm);
        }

        var remaining = new HashSet<int>(Enumerable.Range(0, n));
        var perm = Enumerable.Repeat(-1, n).ToArray();

        foreach (int slot in Enumerable.Range(0, n).OrderByDescending(i => areas[i]))
        {
            int bestPhoto = remaining.OrderBy(p => costs[slot, p]).First();
            perm[slot] = bestPhoto;
            remaining.Remove(bestPhoto);
        }

        double totalScore = Enumerable.Range(0, n).Sum(slot => costs[slot, perm[slot]]);
        return (totalScore, perm);
    }
}
