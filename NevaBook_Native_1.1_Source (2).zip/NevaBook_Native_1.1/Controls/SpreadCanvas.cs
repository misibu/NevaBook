using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using NevaBook.Models;
using NevaBook.Services;

namespace NevaBook.Controls;

public sealed class PhotoDropEventArgs(PhotoItem photo, int targetIndex) : EventArgs
{
    public PhotoItem Photo { get; } = photo;
    public int TargetIndex { get; } = targetIndex;
}

public sealed class SpreadCanvas : FrameworkElement
{
    private Spread? _spread;
    private readonly BitmapCache _cache = new();

    private Rect _pageRect;
    private readonly List<Rect> _cellRects = [];

    private int? _dragSource;
    private int? _swapTarget;
    private Point _dragStart;
    private double _startFocusX;
    private double _startFocusY;

    public double PageWidthMm { get; set; } = 406;
    public double PageHeightMm { get; set; } = 206;
    public bool ShowFold { get; set; } = true;

    public Spread? Spread
    {
        get => _spread;
        set
        {
            _spread = value;
            _ = WarmCurrentSpreadAsync();
            InvalidateVisual();
        }
    }

    public event EventHandler? LayoutChanged;
    public event EventHandler<PhotoDropEventArgs>? ExternalPhotoDropped;

    public SpreadCanvas()
    {
        Focusable = true;
        AllowDrop = true;
        ClipToBounds = true;
        Background = new SolidColorBrush(Color.FromRgb(34, 38, 43));

        _cache.ImageReady += (_, _) => Dispatcher.BeginInvoke(InvalidateVisual);

        DragOver += OnExternalDragOver;
        Drop += OnExternalDrop;
    }

    public Brush Background { get; set; }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        dc.DrawRectangle(Background, null, new Rect(RenderSize));

        double availableW = Math.Max(10, ActualWidth - 28);
        double availableH = Math.Max(10, ActualHeight - 28);
        double scale = Math.Min(availableW / PageWidthMm, availableH / PageHeightMm);

        double pageW = PageWidthMm * scale;
        double pageH = PageHeightMm * scale;
        _pageRect = new Rect(
            (ActualWidth - pageW) / 2.0,
            (ActualHeight - pageH) / 2.0,
            pageW,
            pageH);

        dc.DrawRectangle(Brushes.White, new Pen(Brushes.Gray, 1), _pageRect);
        _cellRects.Clear();

        if (_spread is not null)
        {
            foreach (var item in _spread.Items)
            {
                var rect = new Rect(
                    _pageRect.X + item.Rect.X * scale,
                    _pageRect.Y + item.Rect.Y * scale,
                    Math.Max(1, item.Rect.Width * scale),
                    Math.Max(1, item.Rect.Height * scale));

                _cellRects.Add(rect);

                if (_cache.TryGet(item.Photo.WorkingPath, out var bitmap))
                    DrawCover(dc, bitmap, rect, item.FocusX, item.FocusY);
                else
                {
                    dc.DrawRectangle(new SolidColorBrush(Color.FromRgb(210, 214, 218)), null, rect);
                    _ = _cache.GetAsync(item.Photo.WorkingPath);
                }

                dc.DrawRectangle(null, new Pen(new SolidColorBrush(Color.FromArgb(70, 255, 255, 255)), 1), rect);
            }
        }

        if (ShowFold)
        {
            double x = _pageRect.X + _pageRect.Width / 2.0;
            var pen = new Pen(new SolidColorBrush(Color.FromArgb(130, 80, 80, 80)), 1);
            pen.DashStyle = DashStyles.Dash;
            dc.DrawLine(pen, new Point(x, _pageRect.Top), new Point(x, _pageRect.Bottom));
        }

        if (_dragSource is int source)
        {
            if (_swapTarget is int target && target != source && target < _cellRects.Count)
            {
                dc.DrawRectangle(null, new Pen(Brushes.LimeGreen, 3), _cellRects[target]);
            }
            else if (source < _cellRects.Count)
            {
                dc.DrawRectangle(null, new Pen(new SolidColorBrush(Color.FromRgb(230, 169, 62)), 2), _cellRects[source]);
            }
        }
    }

    private static void DrawCover(
        DrawingContext dc,
        BitmapSource bitmap,
        Rect dest,
        double focusX,
        double focusY)
    {
        double srcW = bitmap.PixelWidth;
        double srcH = bitmap.PixelHeight;
        double slotAspect = dest.Width / Math.Max(1, dest.Height);
        double srcAspect = srcW / Math.Max(1, srcH);

        Rect viewbox;
        if (srcAspect > slotAspect)
        {
            double cropW = srcH * slotAspect;
            double left = (srcW - cropW) * Math.Clamp(focusX, 0, 1);
            viewbox = new Rect(left, 0, cropW, srcH);
        }
        else
        {
            double cropH = srcW / slotAspect;
            double top = (srcH - cropH) * Math.Clamp(focusY, 0, 1);
            viewbox = new Rect(0, top, srcW, cropH);
        }

        var brush = new ImageBrush(bitmap)
        {
            ViewboxUnits = BrushMappingMode.Absolute,
            Viewbox = viewbox,
            Stretch = Stretch.Fill
        };
        dc.DrawRectangle(brush, null, dest);
    }

    private int HitTestCell(Point p)
    {
        for (int i = 0; i < _cellRects.Count; i++)
            if (_cellRects[i].Contains(p))
                return i;
        return -1;
    }

    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonDown(e);
        Focus();

        if (_spread is null) return;
        int index = HitTestCell(e.GetPosition(this));
        if (index < 0) return;

        if (e.ClickCount >= 2)
        {
            _spread.Items[index].FocusX = 0.5;
            _spread.Items[index].FocusY = 0.5;
            _spread.Touch();
            LayoutChanged?.Invoke(this, EventArgs.Empty);
            InvalidateVisual();
            e.Handled = true;
            return;
        }

        _dragSource = index;
        _swapTarget = null;
        _dragStart = e.GetPosition(this);
        _startFocusX = _spread.Items[index].FocusX;
        _startFocusY = _spread.Items[index].FocusY;
        CaptureMouse();
        InvalidateVisual();
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_spread is null || _dragSource is not int source || e.LeftButton != MouseButtonState.Pressed)
            return;

        var pos = e.GetPosition(this);
        int over = HitTestCell(pos);

        if (over >= 0 && over != source)
        {
            _swapTarget = over;
            InvalidateVisual();
            return;
        }

        _swapTarget = null;
        if (source >= _cellRects.Count) return;

        var item = _spread.Items[source];
        if (!_cache.TryGet(item.Photo.WorkingPath, out var bitmap))
            return;

        Rect cell = _cellRects[source];
        double slotAspect = cell.Width / Math.Max(1, cell.Height);
        double srcAspect = bitmap.PixelWidth / (double)Math.Max(1, bitmap.PixelHeight);

        Vector delta = pos - _dragStart;

        if (srcAspect > slotAspect)
        {
            double cropW = bitmap.PixelHeight * slotAspect;
            double maxVisualShift = cell.Width * Math.Max(0.0001, bitmap.PixelWidth / cropW - 1.0);
            item.FocusX = Math.Clamp(_startFocusX - delta.X / maxVisualShift, 0, 1);
        }
        else
        {
            double cropH = bitmap.PixelWidth / slotAspect;
            double maxVisualShift = cell.Height * Math.Max(0.0001, bitmap.PixelHeight / cropH - 1.0);
            item.FocusY = Math.Clamp(_startFocusY - delta.Y / maxVisualShift, 0, 1);
        }

        _spread.Touch();
        InvalidateVisual();
    }

    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonUp(e);

        if (_spread is not null && _dragSource is int source && _swapTarget is int target &&
            source != target && source < _spread.Items.Count && target < _spread.Items.Count)
        {
            (_spread.Items[source].Photo, _spread.Items[target].Photo) =
                (_spread.Items[target].Photo, _spread.Items[source].Photo);

            _spread.Items[source].FocusX = _spread.Items[source].FocusY = 0.5;
            _spread.Items[target].FocusX = _spread.Items[target].FocusY = 0.5;
            _spread.Touch();
        }

        if (_dragSource is not null)
            LayoutChanged?.Invoke(this, EventArgs.Empty);

        _dragSource = null;
        _swapTarget = null;
        ReleaseMouseCapture();
        InvalidateVisual();
    }

    private void OnExternalDragOver(object sender, DragEventArgs e)
    {
        if (_spread is null || !e.Data.GetDataPresent(typeof(PhotoItem)))
        {
            e.Effects = DragDropEffects.None;
            return;
        }

        int target = HitTestCell(e.GetPosition(this));
        e.Effects = target >= 0 ? DragDropEffects.Move : DragDropEffects.None;
        e.Handled = true;
    }

    private void OnExternalDrop(object sender, DragEventArgs e)
    {
        if (_spread is null || !e.Data.GetDataPresent(typeof(PhotoItem))) return;
        if (e.Data.GetData(typeof(PhotoItem)) is not PhotoItem photo) return;

        int target = HitTestCell(e.GetPosition(this));
        if (target < 0) return;

        ExternalPhotoDropped?.Invoke(this, new PhotoDropEventArgs(photo, target));
        InvalidateVisual();
    }

    private async Task WarmCurrentSpreadAsync()
    {
        if (_spread is null) return;
        await _cache.PreloadAsync(_spread.Items.Select(x => x.Photo.WorkingPath));
    }
}
