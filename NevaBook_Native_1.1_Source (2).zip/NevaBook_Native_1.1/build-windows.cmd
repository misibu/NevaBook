@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

echo ===================================================
echo Neva-Book1.1 Native Engine - Windows build
echo ===================================================

where dotnet >nul 2>nul
if errorlevel 1 (
  echo Нужен .NET 8 SDK.
  echo После установки повторите запуск.
  pause
  exit /b 1
)

dotnet restore NevaBook.csproj
if errorlevel 1 goto :error

if exist publish rmdir /s /q publish
if exist artifacts rmdir /s /q artifacts
mkdir publish
mkdir artifacts

echo.
echo 1/2 Portable EXE...
dotnet publish NevaBook.csproj -c Release -r win-x64 --self-contained true ^
  -p:PublishProfile=Portable ^
  -o publish\portable
if errorlevel 1 goto :error

copy /y "publish\portable\Neva-Book1.1.exe" "artifacts\Neva-Book1.1_Portable.exe" >nul

echo.
echo 2/2 Fast installed build...
dotnet publish NevaBook.csproj -c Release -r win-x64 --self-contained true ^
  -p:PublishProfile=Installed ^
  -o publish\installed
if errorlevel 1 goto :error

set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if exist "%ISCC%" (
  "%ISCC%" "Installer\NevaBook.iss"
) else (
  echo.
  echo Inno Setup 6 не найден - portable EXE уже готов.
  echo Для Setup.exe установите Inno Setup 6 и повторите.
)

echo.
echo ГОТОВО. Результаты в папке artifacts
pause
exit /b 0

:error
echo.
echo ОШИБКА СБОРКИ. Пришлите последние строки этого окна.
pause
exit /b 1
